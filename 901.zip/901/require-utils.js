var FF_resource = {
	scriptDeferred: jQuery.Deferred(),
	styleDeferred: jQuery.Deferred(),
	scriptLoading: false,
	styleLoading: false
}